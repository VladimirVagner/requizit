<?php

namespace App\MoonShine;

use Leeto\MoonShine\Dashboard\DashboardScreen;

class Dashboard extends DashboardScreen
{
	public function blocks(): array
	{
		return [];
	}
}
