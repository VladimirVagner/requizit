<?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'moonshine::components.table.index','data' => ['crudMode' => true,'xData' => 'crudTable()','xInit' => '$refs.foot.classList.remove(\'hidden\')']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('moonshine::table'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['crudMode' => true,'x-data' => 'crudTable()','x-init' => '$refs.foot.classList.remove(\'hidden\')']); ?>
     <?php $__env->slot('thead', null, []); ?> 
        <?php echo $__env->make("moonshine::crud.shared.table-head", [$resource], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
     <?php $__env->endSlot(); ?>
     <?php $__env->slot('tbody', null, []); ?> 
        <?php echo $__env->make("moonshine::crud.shared.table-body", [$resource, $items], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
     <?php $__env->endSlot(); ?>

     <?php $__env->slot('tfoot', null, ['x-ref' => 'foot',':class' => 'actionsOpen ? \'translate-y-none ease-out\' : \'-translate-y-full ease-in hidden\'']); ?> 
        <?php echo $__env->renderWhen(!$resource->isPreviewMode(), "moonshine::crud.shared.table-foot", [$resource], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path'])); ?>
     <?php $__env->endSlot(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>




<?php /**PATH /var/www/vendor/lee-to/moonshine/resources/views/crud/shared/table.blade.php ENDPATH**/ ?>