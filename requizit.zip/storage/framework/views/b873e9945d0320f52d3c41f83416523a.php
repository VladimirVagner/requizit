<div class="form-error"><?php echo e($slot, false); ?></div>
<?php /**PATH /var/www/vendor/lee-to/moonshine/resources/views/components/form/input-error.blade.php ENDPATH**/ ?>