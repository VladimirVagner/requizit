<div class="col-span-12 lg:col-span-8">
    <div class="mt-3 flex w-full flex-wrap justify-end gap-2">
        <?php echo $__env->make('moonshine::crud.shared.item-actions', [
            'resource' => $resource,
            'item' => $item,
            'except' => ['show']
        ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</div>
<?php /**PATH /var/www/vendor/lee-to/moonshine/resources/views/crud/shared/detail-card-actions.blade.php ENDPATH**/ ?>