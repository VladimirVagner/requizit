<?php echo $__env->make('moonshine::fields.input', [
    'element' => $element,
    'item' => $resource->getModel(),
    'resource' => $resource,
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH /var/www/vendor/lee-to/moonshine/resources/views/filters/text.blade.php ENDPATH**/ ?>