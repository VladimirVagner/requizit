<?php $__env->startSection('title', $title); ?>

<h1 class="<?php echo e(isset($subTitle) && $subTitle ?: 'mb-6', false); ?> truncate text-md font-medium">
    <?php echo e($title, false); ?>

</h1>

<?php if($subTitle ?? false): ?>
    <div class="pt-2 mb-6"><?php echo $subTitle; ?></div>
<?php endif; ?>
<?php /**PATH /var/www/vendor/lee-to/moonshine/resources/views/layouts/shared/title.blade.php ENDPATH**/ ?>