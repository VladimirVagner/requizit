<div class="grid grid-cols-12 gap-6">
    <?php echo e($slot, false); ?>

</div>
<?php /**PATH /var/www/vendor/lee-to/moonshine/resources/views/components/grid.blade.php ENDPATH**/ ?>