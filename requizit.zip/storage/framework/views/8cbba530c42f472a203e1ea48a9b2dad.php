<?php if(method_exists($element, 'isTree') && $element->isTree()): ?>
    <?php echo $__env->make('moonshine::fields.tree', [
        'element' => $element,
        'item' => $item,
        'resource' => $resource
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php else: ?>

    <?php if(method_exists($element, 'isOnlySelected') && $element->isOnlySelected()): ?>
        <div x-data="search('<?php echo e(route('moonshine.search.relations', class_basename($element)), false); ?>', '<?php echo e($resource->uriKey(), false); ?>', '<?php echo e($element->field(), false); ?>')">
            <div class="dropdown">
                <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'moonshine::components.form.input','data' => ['xModel' => 'query','@input.debounce' => 'search','placeholder' => trans('moonshine::ui.search')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('moonshine::form.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['x-model' => 'query','@input.debounce' => 'search','placeholder' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(trans('moonshine::ui.search'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                <div class="dropdown-body pointer-events-auto visible opacity-100">
                    <div class="dropdown-content">
                        <ul class="dropdown-menu">
                            <template x-for="(item, key) in match">
                                <li class="dropdown-item">
                                    <a href="#"
                                       class="dropdown-menu-link"
                                       x-text="item"
                                       @click.prevent="select(key)"
                                    />
                                </li>
                            </template>
                        </ul>
                    </div>
                </div>
            </div>
            <template x-for="item in items">
                <div x-data="pivot" x-init="autoCheck" class="mt-3">
                    <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'moonshine::components.form.pivot','data' => ['label' => '<span x-text=\'item.value\' />','xBind:id' => '`'.e($element->id('${item.key}'), false).'`','xBind:name' => '`'.e($element->name('${item.key}'), false).'`','xBind:value' => 'item.key','checked' => true,'withFields' => true,'attributes' => $element->attributes()]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('moonshine::form.pivot'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('<span x-text=\'item.value\' />'),'x-bind:id' => '`'.e($element->id('${item.key}'), false).'`','x-bind:name' => '`'.e($element->name('${item.key}'), false).'`','x-bind:value' => 'item.key','checked' => true,'withFields' => true,'attributes' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($element->attributes())]); ?>
                        <?php if($element->getFields()->isNotEmpty()): ?>
                            <?php $__currentLoopData = $element->getFields(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pivotField): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php echo e($resource->renderComponent(
                                        $pivotField->setAttribute('x-bind:name', '`'.(preg_replace('/\[\]$/', '[${item.key}]', $pivotField->name()).'`')),
                                        $element->pivotValue($item, null)
                                ), false); ?>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                </div>
            </template>
        </div>
    <?php endif; ?>

    <?php $__currentLoopData = $element->values(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $optionValue => $optionName): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div x-data="pivot" x-init="autoCheck" class="mt-1 first-of-type:mt-0">
            <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'moonshine::components.form.pivot','data' => ['id' => ''.e($element->id($optionValue), false).'','name' => ''.e($element->name($optionValue), false).'','label' => ''.e($optionName, false).'','value' => ''.e($optionValue, false).'','checked' => $element->isChecked($item, $optionValue),'withFields' => $element->getFields()->isNotEmpty(),'attributes' => $element->attributes()]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('moonshine::form.pivot'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => ''.e($element->id($optionValue), false).'','name' => ''.e($element->name($optionValue), false).'','label' => ''.e($optionName, false).'','value' => ''.e($optionValue, false).'','checked' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($element->isChecked($item, $optionValue)),'withFields' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($element->getFields()->isNotEmpty()),'attributes' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($element->attributes())]); ?>
                <?php if($element->getFields()->isNotEmpty()): ?>
                    <?php $__currentLoopData = $element->getFields(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pivotField): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo e($resource->renderComponent(
                                $pivotField->clearXModel()->setName(preg_replace('/\[\]$/', "[$optionValue]", $pivotField->name())),
                                $element->pivotValue($item, $optionValue)
                        ), false); ?>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<?php /**PATH /var/www/vendor/lee-to/moonshine/resources/views/fields/multi-checkbox.blade.php ENDPATH**/ ?>