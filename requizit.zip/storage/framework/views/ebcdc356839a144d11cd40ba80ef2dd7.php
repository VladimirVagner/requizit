<input <?php echo e($attributes->merge([
    'class' => !in_array($attributes->get('type'), ['checkbox', 'radio', 'color'])
        ? 'form-input'
        : 'form-' . $attributes->get('type', 'input'),
    'type' => 'text']), false); ?>

/>
<?php /**PATH /var/www/vendor/lee-to/moonshine/resources/views/components/form/input.blade.php ENDPATH**/ ?>