<a href="<?php echo e(route('moonshine.index'), false); ?>" class="block" rel="home">
    <?php if(config('moonshine.logo')): ?>
        <img class="h-14 xl:block"
             src="<?php echo e(config('moonshine.logo'), false); ?>"
             alt="<?php echo e(config('moonshine.title'), false); ?>"
        />
    <?php else: ?>
        <img src="<?php echo e(asset('vendor/moonshine/logo.svg'), false); ?>"
             class="hidden h-14 xl:block"
             :class="minimizedMenu && '!hidden'"
             alt="<?php echo e(config('moonshine.title'), false); ?>"
        />
        <img src="<?php echo e(asset('vendor/moonshine/logo-small.svg'), false); ?>"
             class="block h-8 lg:h-10 xl:hidden"
             :class="minimizedMenu && '!block'"
             alt="<?php echo e(config('moonshine.title'), false); ?>"
        />
    <?php endif; ?>
</a>
<?php /**PATH /var/www/vendor/lee-to/moonshine/resources/views/layouts/shared/logo.blade.php ENDPATH**/ ?>