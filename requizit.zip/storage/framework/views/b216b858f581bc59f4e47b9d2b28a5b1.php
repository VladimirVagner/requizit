<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps([
    'searchable' => false,
    'nullable' => false,
    'values' => [],
    'options' => false
]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps([
    'searchable' => false,
    'nullable' => false,
    'values' => [],
    'options' => false
]); ?>
<?php foreach (array_filter(([
    'searchable' => false,
    'nullable' => false,
    'values' => [],
    'options' => false
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<select
    <?php echo e($attributes->merge([
        'class' => 'form-select',
        'type' => 'text',
        'x-data' => 'select',
        'x-ref' => 'select',
        'data-search-enabled' => $searchable,
        'data-remove-item-button' => $nullable
    ]), false); ?>

>
    <?php if($options ?? false): ?>
        <?php echo e($options, false); ?>

    <?php else: ?>
        <?php $__currentLoopData = $values; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option <?php if($value == $attributes->get('value', '')): echo 'selected'; endif; ?>
                    value="<?php echo e($value, false); ?>"
            >
                <?php echo e($label, false); ?>

            </option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
</select>
<?php /**PATH /var/www/vendor/lee-to/moonshine/resources/views/components/form/select.blade.php ENDPATH**/ ?>