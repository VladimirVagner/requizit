<?php if($value !== false): ?>
    <span class="badge badge-<?php echo e($color, false); ?>">
        <?php echo $value; ?>

    </span>
<?php else: ?>
    &mdash;
<?php endif; ?>
<?php /**PATH /var/www/vendor/lee-to/moonshine/resources/views/ui/badge.blade.php ENDPATH**/ ?>