<div>
    <?php echo $__env->make('moonshine::fields.' . ($element->isGroup() ? 'multi-checkbox' : 'input'), [
        'element' => $element,
        'item' => $item,
        'resource' => $resource
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<?php /**PATH /var/www/vendor/lee-to/moonshine/resources/views/fields/checkbox.blade.php ENDPATH**/ ?>