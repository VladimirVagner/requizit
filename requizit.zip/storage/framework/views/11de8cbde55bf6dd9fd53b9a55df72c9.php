<?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr class="bgc-<?php echo e($resource->trClass($item, $loop->index), false); ?>" style="<?php echo e($resource->trStyles($item, $loop->index), false); ?>">
        <?php if($resource->hasMassAction()): ?>
            <td class="w-10 text-center bgc-<?php echo e($resource->tdClass($item, $loop->index, 0), false); ?>" style="<?php echo e($resource->tdStyles($item, $loop->index, 0), false); ?>">
                <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'moonshine::components.form.input','data' => ['type' => 'checkbox','@change' => 'actions(\'row\')','name' => 'items['.e($item->getKey(), false).']','class' => 'tableActionRow','value' => ''.e($item->getKey(), false).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('moonshine::form.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'checkbox','@change' => 'actions(\'row\')','name' => 'items['.e($item->getKey(), false).']','class' => 'tableActionRow','value' => ''.e($item->getKey(), false).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
            </td>
        <?php endif; ?>

        <?php $__currentLoopData = $resource->getFields()->indexFields(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <td class="bgc-<?php echo e($resource->tdClass($item, $loop->parent->index, $index + 1), false); ?>"
                style="<?php echo e($resource->tdStyles($item, $loop->parent->index, $index + 1), false); ?>"
            >
                <?php echo $field->indexViewValue($item); ?>

            </td>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php if(!$resource->isPreviewMode()): ?>
            <td class="bgc-<?php echo e($resource->tdClass($item, $loop->index, count($resource->getFields()->indexFields()) + 1), false); ?>"
                style="<?php echo e($resource->tdStyles($item, $loop->index, count($resource->getFields()->indexFields()) + 1), false); ?>"
            >
                <?php echo $__env->make("moonshine::crud.shared.table-row-actions", ["item" => $item, "resource" => $resource], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </td>
        <?php endif; ?>
    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH /var/www/vendor/lee-to/moonshine/resources/views/crud/shared/table-body.blade.php ENDPATH**/ ?>