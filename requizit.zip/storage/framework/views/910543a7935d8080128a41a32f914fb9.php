<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"
     class="fill-current w-<?php echo e($size ?? 5, false); ?> h-<?php echo e($size ?? 5, false); ?> <?php echo e($class ?? '', false); ?> <?php echo e(isset($color) ? "text-$color" : '', false); ?>">
  <path fill-rule="evenodd" d="M6.72 5.66l11.62 11.62A8.25 8.25 0 006.72 5.66zm10.56 12.68L5.66 6.72a8.25 8.25 0 0011.62 11.62zM5.105 5.106c3.807-3.808 9.98-3.808 13.788 0 3.808 3.807 3.808 9.98 0 13.788-3.807 3.808-9.98 3.808-13.788 0-3.808-3.807-3.808-9.98 0-13.788z" clip-rule="evenodd"/>
</svg>
<?php /**PATH /var/www/vendor/lee-to/moonshine/resources/views/ui/icons/heroicons/no-symbol.blade.php ENDPATH**/ ?>